"""Run EDA, feature engineering, model training, and evaluation."""
from pathlib import Path
import sqlite3
import sys
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (classification_report,
                             precision_recall_fscore_support, roc_auc_score)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(Path(__file__).parent))
from generate_data import generate


def main():
    raw = ROOT / "data/raw/customers.csv"
    data = generate(raw) if not raw.exists() else pd.read_csv(raw)
    reports, processed = ROOT / "reports", ROOT / "data/processed"
    reports.mkdir(exist_ok=True); processed.mkdir(parents=True, exist_ok=True)
    # Feature engineering: tenure buckets and spend-to-tenure proxy.
    data["tenure_band"] = pd.cut(data.tenure_months, [-1, 12, 24, 48, 100], labels=["0-12", "13-24", "25-48", "49+"])
    data["avg_lifetime_monthly_spend"] = data.total_charges / (data.tenure_months + 1)
    with sqlite3.connect(processed / "churn.db") as connection:
        data.to_sql("customers", connection, if_exists="replace", index=False)
    eda = data.groupby("contract_type", observed=True).agg(customers=("churn", "size"), churn_rate=("churn", "mean")).reset_index()
    eda.churn_rate = (100 * eda.churn_rate).round(2); eda.to_csv(reports / "churn_by_contract.csv", index=False)
    X, y = data.drop(columns=["customer_id", "churn"]), data.churn
    categorical = [column for column in X.columns if (
        pd.api.types.is_object_dtype(X[column])
        or pd.api.types.is_string_dtype(X[column])
        or isinstance(X[column].dtype, pd.CategoricalDtype)
    )]
    numerical = [c for c in X.columns if c not in categorical]
    prep = ColumnTransformer([("numbers", Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), numerical),
                              ("categories", OneHotEncoder(handle_unknown="ignore"), categorical)])
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.25, stratify=y, random_state=42)
    models = {"logistic_regression": LogisticRegression(max_iter=2000, class_weight="balanced"),
              "random_forest": RandomForestClassifier(n_estimators=350, min_samples_leaf=3, class_weight="balanced", random_state=42)}
    rows = []
    for name, estimator in models.items():
        pipe = Pipeline([("prep", prep), ("model", estimator)]).fit(X_train, y_train)
        predictions, scores = pipe.predict(X_test), pipe.predict_proba(X_test)[:, 1]
        precision, recall, f1, _ = precision_recall_fscore_support(y_test, predictions, average="binary", zero_division=0)
        rows.append({"model": name, "precision": precision, "recall": recall, "f1": f1, "roc_auc": roc_auc_score(y_test, scores)})
        if name == "random_forest":
            pd.DataFrame(classification_report(y_test, predictions, output_dict=True)).T.to_csv(reports / "random_forest_classification_report.csv")
    metrics = pd.DataFrame(rows).round(4); metrics.to_csv(reports / "model_metrics.csv", index=False)
    print("Complete. Best model by ROC-AUC:\n", metrics.sort_values("roc_auc", ascending=False).head(1).to_string(index=False))


if __name__ == "__main__":
    main()
