"""Generate a deterministic, demo-only telecom churn dataset."""
from pathlib import Path
import numpy as np
import pandas as pd


def generate(output_path: Path, n_rows: int = 1500, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    contract = rng.choice(["Month-to-month", "One year", "Two year"], n_rows, p=[.56, .24, .20])
    internet = rng.choice(["Fiber optic", "DSL", "None"], n_rows, p=[.46, .43, .11])
    tenure = rng.integers(0, 73, n_rows)
    monthly = np.clip(rng.normal(72, 24, n_rows) + (internet == "Fiber optic") * 15, 18, 130).round(2)
    paperless = rng.choice(["Yes", "No"], n_rows, p=[.62, .38])
    support = rng.choice(["Yes", "No"], n_rows, p=[.42, .58])
    probability = (0.08 + .25 * (contract == "Month-to-month") + .13 * (internet == "Fiber optic")
                   + .12 * (support == "No") + .08 * (paperless == "Yes") - .004 * tenure
                   + .0008 * (monthly - 70))
    churn = (rng.random(n_rows) < np.clip(probability, .02, .88)).astype(int)
    frame = pd.DataFrame({
        "customer_id": [f"C{i:05d}" for i in range(1, n_rows + 1)], "gender": rng.choice(["Female", "Male"], n_rows),
        "senior_citizen": rng.choice([0, 1], n_rows, p=[.84, .16]), "tenure_months": tenure,
        "internet_service": internet, "contract_type": contract, "paperless_billing": paperless,
        "tech_support": support, "monthly_charges": monthly, "total_charges": (monthly * (tenure + 1)).round(2), "churn": churn,
    })
    output_path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output_path, index=False)
    return frame


if __name__ == "__main__":
    generate(Path(__file__).parents[1] / "data/raw/customers.csv")
