-- Segment-level churn analysis used to complement the Python EDA.
SELECT
  contract_type,
  internet_service,
  COUNT(*) AS customers,
  ROUND(100.0 * AVG(churn), 2) AS churn_rate_pct,
  ROUND(AVG(tenure_months), 1) AS avg_tenure_months,
  ROUND(AVG(monthly_charges), 2) AS avg_monthly_charges
FROM customers
GROUP BY contract_type, internet_service
ORDER BY churn_rate_pct DESC;
