# Customer Churn Prediction

An end-to-end telecom customer churn classification project. It creates a realistic synthetic dataset, explores churn patterns, engineers features, compares baseline and tuned models, and saves evaluation outputs.

## Skills demonstrated

- Python, Pandas, NumPy, SQLite, Scikit-learn
- Data quality checks, exploratory data analysis, and feature engineering
- Logistic Regression and Random Forest classification
- Precision, recall, F1 score, ROC-AUC, confusion matrix, and ROC curve evaluation

## Run

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python src/run_pipeline.py
```

Outputs are written to `data/processed/` and `reports/`, including segment EDA, model metrics, and a classification report. The source data is generated deterministically by `src/generate_data.py`; replace `data/raw/customers.csv` with a real, consented dataset to adapt the project.

## SQL analysis

`sql/churn_analysis.sql` calculates segment-level customer count, churn rate, tenure, and revenue from the SQLite database created by the pipeline. Run it in any SQLite client against `data/processed/churn.db`.

## Notes

The generated data is for demonstration only. Metrics are not presented as real business results.
