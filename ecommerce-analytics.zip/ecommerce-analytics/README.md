# E-Commerce Sales & Customer Analytics

This project converts generated order-line data into clean business tables and KPI exports ready for Power BI, Tableau, or another BI tool.

## Skills demonstrated

- SQL, Python, Pandas, customer and product analytics
- Revenue, order, average-order-value, customer, and product performance analysis
- Reproducible BI-ready fact and dimension exports

## Run

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python src/build_analytics.py
```

The pipeline creates a deterministic sample dataset and outputs CSV files in `data/powerbi/`, a SQLite database in `data/processed/`, and a Markdown report in `reports/`.

## Browser dashboard

Open `dashboard/index.html` in a browser for a finished dashboard preview based on the project data. It is included for portfolio viewing; it is not a Power BI `.pbix` file.

## Power BI dashboard setup

Power BI `.pbix` files cannot be produced natively here. Import all files in `data/powerbi/` and relate `fact_sales` to `dim_customers` by `customer_id`, to `dim_products` by `product_id`, and to `dim_date` by `order_date`.

Build these report pages:

1. **Executive overview:** cards for Revenue, Orders, Customers, and AOV; monthly revenue line; category revenue bar.
2. **Customer analysis:** customer segment revenue, new vs returning customer counts, top customers table.
3. **Product analysis:** top products by revenue and units; category margin and discount performance.

Suggested measures are in `powerbi/measures.md`. The exact fields and visual definitions are in `powerbi/dashboard_spec.md`.
