# Dashboard specification

| Page | Visual | Fields / measure |
|---|---|---|
| Executive overview | KPI cards | Revenue, Orders, Customers, AOV |
| Executive overview | Line chart | `dim_date[month]`, Revenue |
| Executive overview | Bar chart | `dim_products[category]`, Revenue |
| Customer analysis | Stacked bar | `dim_customers[segment]`, Revenue |
| Customer analysis | Table | Customer name, Orders, Revenue |
| Product analysis | Bar chart | Product name, Revenue, Units Sold |
| Product analysis | Matrix | Category, Revenue, Gross Margin, Margin % |

Include slicers for order date, region, category, and customer segment.
