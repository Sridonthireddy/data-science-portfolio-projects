# Suggested DAX measures

```DAX
Revenue = SUM(fact_sales[net_sales])
Orders = DISTINCTCOUNT(fact_sales[order_id])
Customers = DISTINCTCOUNT(fact_sales[customer_id])
AOV = DIVIDE([Revenue], [Orders])
Units Sold = SUM(fact_sales[quantity])
Gross Margin = SUM(fact_sales[gross_margin])
Margin % = DIVIDE([Gross Margin], [Revenue])
```
