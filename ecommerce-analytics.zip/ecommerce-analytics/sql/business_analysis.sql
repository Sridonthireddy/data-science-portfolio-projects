-- Monthly sales and average order value.
SELECT strftime('%Y-%m', order_date) AS month,
       ROUND(SUM(net_sales), 2) AS revenue,
       COUNT(DISTINCT order_id) AS orders,
       ROUND(SUM(net_sales) / COUNT(DISTINCT order_id), 2) AS avg_order_value
FROM fact_sales
GROUP BY month
ORDER BY month;
