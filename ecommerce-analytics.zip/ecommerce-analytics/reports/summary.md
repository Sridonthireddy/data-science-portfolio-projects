# E-Commerce Analytics Report

- Revenue: $602,292.29
- Orders: 2,200
- Customers: 299
- Average order value: $273.77

## Top customers

| Customer | Revenue | Orders |
|---|---:|---:|
| Customer 236 | $5,899.58 | 13 |
| Customer 189 | $5,480.47 | 15 |
| Customer 209 | $5,070.67 | 12 |
| Customer 85 | $5,040.15 | 12 |
| Customer 113 | $4,644.75 | 13 |
| Customer 41 | $4,563.80 | 10 |
| Customer 12 | $4,491.55 | 11 |
| Customer 33 | $4,407.83 | 14 |
| Customer 230 | $4,403.27 | 9 |
| Customer 146 | $4,152.50 | 10 |