"""Generate e-commerce data and produce analysis-ready tables and reports."""
from pathlib import Path
import sqlite3
import numpy as np
import pandas as pd

ROOT = Path(__file__).parents[1]


def main(seed=21):
    rng = np.random.default_rng(seed)
    raw, processed, output, reports = (ROOT / "data/raw", ROOT / "data/processed", ROOT / "data/powerbi", ROOT / "reports")
    for folder in (raw, processed, output, reports): folder.mkdir(parents=True, exist_ok=True)
    products = pd.DataFrame({"product_id": [f"P{i:03}" for i in range(1, 21)],
        "product_name": [f"Product {i}" for i in range(1, 21)],
        "category": np.repeat(["Electronics", "Home", "Fashion", "Beauty"], 5),
        "unit_cost": rng.uniform(8, 90, 20).round(2)})
    customers = pd.DataFrame({"customer_id": [f"U{i:04}" for i in range(1, 301)],
        "customer_name": [f"Customer {i}" for i in range(1, 301)],
        "segment": rng.choice(["Consumer", "Corporate", "Home Office"], 300, p=[.58,.24,.18]),
        "region": rng.choice(["North", "South", "East", "West"], 300)})
    n = 2200
    orders = pd.DataFrame({"order_id": [f"O{i:05}" for i in range(1, n + 1)], "order_date": pd.Timestamp("2025-01-01") + pd.to_timedelta(rng.integers(0, 365, n), unit="D"),
        "customer_id": rng.choice(customers.customer_id, n), "product_id": rng.choice(products.product_id, n),
        "quantity": rng.integers(1, 6, n), "discount_pct": rng.choice([0, .05, .10, .15], n, p=[.54,.22,.17,.07])})
    fact = orders.merge(products, on="product_id").merge(customers, on="customer_id")
    fact["unit_price"] = (fact.unit_cost * rng.uniform(1.35, 2.15, n)).round(2)
    fact["gross_sales"] = (fact.quantity * fact.unit_price).round(2)
    fact["discount_amount"] = (fact.gross_sales * fact.discount_pct).round(2)
    fact["net_sales"] = (fact.gross_sales - fact.discount_amount).round(2)
    fact["gross_margin"] = (fact.net_sales - fact.quantity * fact.unit_cost).round(2)
    date = pd.DataFrame({"order_date": pd.date_range(fact.order_date.min(), fact.order_date.max(), freq="D")})
    date["month"] = date.order_date.dt.strftime("%Y-%m"); date["quarter"] = "Q" + date.order_date.dt.quarter.astype(str); date["year"] = date.order_date.dt.year
    fact.to_csv(raw / "orders.csv", index=False)
    fact.to_csv(output / "fact_sales.csv", index=False); customers.to_csv(output / "dim_customers.csv", index=False); products.to_csv(output / "dim_products.csv", index=False); date.to_csv(output / "dim_date.csv", index=False)
    monthly = fact.assign(month=fact.order_date.dt.strftime("%Y-%m")).groupby("month").agg(revenue=("net_sales","sum"), orders=("order_id","nunique"), customers=("customer_id","nunique"), units=("quantity","sum")).reset_index()
    monthly["aov"] = (monthly.revenue / monthly.orders).round(2); monthly.round(2).to_csv(output / "monthly_kpis.csv", index=False)
    category = fact.groupby("category").agg(revenue=("net_sales","sum"), units=("quantity","sum"), margin=("gross_margin","sum")).reset_index().round(2); category.to_csv(output / "category_kpis.csv", index=False)
    top = fact.groupby(["customer_id", "customer_name"], as_index=False).agg(revenue=("net_sales","sum"), orders=("order_id","nunique")).sort_values("revenue", ascending=False).head(10).round(2)
    with sqlite3.connect(processed / "ecommerce.db") as con:
        fact.to_sql("fact_sales", con, if_exists="replace", index=False); customers.to_sql("dim_customers", con, if_exists="replace", index=False); products.to_sql("dim_products", con, if_exists="replace", index=False)
    top_table = "| Customer | Revenue | Orders |\n|---|---:|---:|\n" + "\n".join(
        f"| {row.customer_name} | ${row.revenue:,.2f} | {row.orders} |" for row in top.itertuples()
    )
    summary = f"# E-Commerce Analytics Report\n\n- Revenue: ${fact.net_sales.sum():,.2f}\n- Orders: {fact.order_id.nunique():,}\n- Customers: {fact.customer_id.nunique():,}\n- Average order value: ${fact.net_sales.sum() / fact.order_id.nunique():,.2f}\n\n## Top customers\n\n" + top_table
    (reports / "summary.md").write_text(summary)
    print("Complete. Power BI-ready files are in data/powerbi/.")

if __name__ == "__main__": main()
