"""A reproducible content-based movie recommendation pipeline."""
from pathlib import Path
import argparse
import re
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

ROOT = Path(__file__).parents[1]

MOVIES = [
 ("Galactic Frontier", "Science Fiction Adventure", "space exploration alien planet future", "A daring crew explores a remote planet beyond the solar system.", "Asha Khan Leo Reed"),
 ("Orbit of Hope", "Science Fiction Drama", "space survival astronaut future", "An astronaut struggles to return home after a deep space mission fails.", "Maya Stone Leo Reed"),
 ("Neon City", "Science Fiction Thriller", "cyberpunk detective artificial intelligence city", "A detective follows a dangerous artificial intelligence through a neon metropolis.", "Noah Park Asha Khan"),
 ("The Last Signal", "Science Fiction Mystery", "space signal alien mystery", "Scientists decode a strange signal received from a distant world.", "Maya Stone Omar Bell"),
 ("Wildwood Promise", "Romance Drama", "small town love family", "Two old friends reconnect while restoring a family home.", "Sofia Lane Noah Park"),
 ("Summer Letters", "Romance Comedy", "love letters coastal town", "A lost bundle of letters brings two strangers together by the sea.", "Sofia Lane Jamie Cole"),
 ("Shadow Protocol", "Action Thriller", "spy conspiracy covert mission", "A former agent uncovers a conspiracy within an intelligence agency.", "Omar Bell Jamie Cole"),
 ("Midnight Pursuit", "Action Crime", "detective chase crime city", "A determined detective races across the city to stop a criminal network.", "Noah Park Omar Bell"),
 ("Kingdom of Ember", "Fantasy Adventure", "dragon kingdom magic quest", "A young guardian crosses a magical kingdom to awaken an ancient dragon.", "Asha Khan Sofia Lane"),
 ("The Crystal Gate", "Fantasy Adventure", "magic portal kingdom quest", "Three friends enter a hidden world through a luminous gate.", "Leo Reed Jamie Cole"),
 ("Laughing Matter", "Comedy", "friends workplace comedy", "A mismatched team tries to save their small neighborhood theatre.", "Jamie Cole Sofia Lane"),
 ("The Quiet House", "Horror Mystery", "haunted house ghost family", "A family discovers that their new house holds a frightening secret.", "Maya Stone Omar Bell"),
]


def clean_text(value):
    return re.sub(r"[^a-z0-9 ]", " ", str(value).lower()).replace("  ", " ").strip()


def generate_data(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(MOVIES, columns=["title", "genres", "keywords", "overview", "cast"])
    frame.to_csv(path, index=False)
    return frame


class MovieRecommender:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        self.movies = None
        self.matrix = None

    def fit(self, movies):
        self.movies = movies.copy().drop_duplicates("title").reset_index(drop=True)
        # Combine cleaned metadata into one searchable content field.
        fields = ["genres", "keywords", "overview", "cast"]
        self.movies["content"] = self.movies[fields].fillna("").astype(str).agg(" ".join, axis=1).map(clean_text)
        self.matrix = self.vectorizer.fit_transform(self.movies.content)
        return self

    def recommend(self, title, top_n=5):
        matches = self.movies.index[self.movies.title.str.casefold() == title.casefold()].tolist()
        if not matches:
            choices = ", ".join(self.movies.title.tolist())
            raise ValueError(f"Movie not found: {title}. Available titles: {choices}")
        index = matches[0]
        scores = linear_kernel(self.matrix[index], self.matrix).ravel()
        ranked = scores.argsort()[::-1]
        ranked = [i for i in ranked if i != index][:top_n]
        result = self.movies.loc[ranked, ["title", "genres", "overview"]].copy()
        result.insert(1, "similarity", scores[ranked].round(3))
        return result.reset_index(drop=True)

    def fit_or_load(self):
        model_path, data_path = ROOT / "models/content_recommender.joblib", ROOT / "data/raw/movies.csv"
        if model_path.exists():
            loaded = joblib.load(model_path); self.__dict__.update(loaded.__dict__); return self
        movies = generate_data(data_path) if not data_path.exists() else pd.read_csv(data_path)
        self.fit(movies); model_path.parent.mkdir(exist_ok=True); joblib.dump(self, model_path); return self


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--title", help="Movie title to use as the seed")
    parser.add_argument("--top-n", type=int, default=5)
    parser.add_argument("--list", action="store_true", help="List available titles")
    args = parser.parse_args()
    recommender = MovieRecommender().fit_or_load()
    if args.list:
        print("\n".join(recommender.movies.title)); return
    if not args.title:
        parser.error("--title is required unless --list is used")
    print(recommender.recommend(args.title, args.top_n).to_string(index=False))

if __name__ == "__main__": main()
