# Movie Recommendation System

A content-based recommender that uses movie title, genres, keywords, cast, and overview text. It cleans metadata, builds TF-IDF features, calculates cosine similarity, and returns similar movies through both a Python API and command-line interface.

## Skills demonstrated

- Python, Pandas, Scikit-learn
- Text preprocessing and feature extraction with TF-IDF
- Cosine similarity and a reusable recommendation pipeline

## Run

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python src/recommender.py --title "Galactic Frontier" --top-n 5
```

The first run creates `data/raw/movies.csv` and saves the fitted pipeline to `models/content_recommender.joblib`. Use a title printed by `python src/recommender.py --list`.

## Python use

```python
from src.recommender import MovieRecommender
recommender = MovieRecommender().fit_or_load()
print(recommender.recommend("Galactic Frontier", top_n=5))
```

The bundled data is synthetic and is intended to demonstrate the pipeline, not to represent an external movie catalog.
